from django.apps import AppConfig


class DjangoPaymentsClickConfig(AppConfig):
    name = 'django_payments_click'
